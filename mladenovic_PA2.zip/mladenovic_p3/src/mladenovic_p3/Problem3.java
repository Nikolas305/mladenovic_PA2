package mladenovic_p3;
import java.util.Scanner;

public class Problem3 {

	public static void main(String[] args) {
		
		Scanner scnr = new Scanner(System.in);
       
		//topics to ask users string
		
		String[] topics = {"Beach", "Boating", "Fishing", "Swiming", "Surfing"};
        
        int[][] responses = new int [topics.length][];
        
        	int i; 
        
        	int j;
        
        	int people; 
        
        	int rating;

        	for(i= 0 ; i< responses.length; i++) { 
               responses[i] = new int[10];
               
        	for(j= 0 ; j< responses[i].length; j++) {
            	responses[i][j] = 0;
            	       	 
        		
        				}
        		}
       //ask and read imputs values enterd by user 
        	
        System.out.print("How many people are answering the survey: ");
        people = scnr.nextInt();
        

        for(i= 0; i < people; i++) {
        	System.out.println("Rate each topic in the scale 1-10 (1 lowest - 10 hightest) "+topics.length+" topics : ");
        	
        	for(j= 0; j < topics.length; j++) {
                      
        			System.out.print("Enter your rating " + topics[j]+ " : ");
                      rating = scnr.nextInt();
                   
                      		responses[j][rating-1]++; 
              
        				}
        			
        			
        			} 
        	
        scnr.close();
        //end user responses
        int avgRating[] = new int[topics.length];
       
        String highestPointIssue = ""; 
        String lowestPointIssue= "";
       
        int highestPointTotal = 0;
        
        int lowestPointTotal = 0;    
        
        for(i= 0;i < responses.length; i++) {
              avgRating[i] = 0;
              for(j = 0; j < responses[i].length; j++)
                      avgRating[i] += (responses [i][j] * (j + 1));
              
               if(i == 0) 
            	   {
            	   	  highestPointTotal = avgRating[i];
                      lowestPointTotal = avgRating[i];
                      highestPointIssue = topics[i];
                      lowestPointIssue = topics[i];
            	   }
               		
               	else 
               				
               		{
                 if(avgRating[i] > highestPointTotal) {
                            highestPointIssue = topics[i];
                            highestPointTotal = avgRating[i];
                      }                     
                     
                 if(avgRating[i] < lowestPointTotal) {
                            lowestPointIssue = topics[i];
                            lowestPointTotal = avgRating[i];
                      }
               
               }   
               
               				avgRating[i] = avgRating[i] / people;
        }
       
        //white spaces for chart
        System.out.printf("\n%-10s","");
        for(i= 0;i < 10; i++)
        	
               System.out.printf("%-10d", (i + 1));
      //line plus values
        System.out.printf("%10s", "average vote");
        System.out.print("\n-------------------------------------------------------------------------------------------------------------------------------------");
        System.out.println();
        
        for(i=0; i < responses.length; i++) {
        	System.out.printf("\n%-10s", topics[i]);
        	
        	for(j=0;j<responses[i].length; j++)
        		
        		System.out.printf("%-10d", responses[i][j]);
        		System.out.printf("%-15d", avgRating[i]);

        }
      
        System.out.println();
        System.out.println("\nhighest point total: "  + highestPointTotal + " activity - " + highestPointIssue);
        
        System.out.println();
        System.out.println("lowest point total: " + lowestPointTotal +  " activity - " + lowestPointIssue);
       
        
  }

}


